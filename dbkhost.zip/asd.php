<?php


$percentage = 20;

$price = 3;
		$price = ($percentage / 100) * $price;

echo $price;
?>