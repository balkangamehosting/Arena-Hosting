<?php 
echo getenv('REMOTE_ADDR');
?>